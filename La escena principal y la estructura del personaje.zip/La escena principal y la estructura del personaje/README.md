# TutorialUnity2D
 3.1. La escena principal y la estructura del personaje
